const { Sequelize, Op } = require('sequelize');
const { Client, Products, Review } = require('../db.js');

const getReviews = async (filters) => {
    let { product, user, rating, orderField, order } = filters
    rating = rating ? rating : 1
    product = product ? parseInt(product) : null;
    user = user ? user : '%';
    try {
        const tReviews = await Review.findAll(
            {
                include: {
                    model: Client,
                    through: {
                        attributes: ['email']
                      }
                },
                where: {
                    ClientPhone: {
                        [Op.like]: user
                    },
                    ProductIdProduct: product ? product : { [Op.ne]: null },
                    stars: {
                        [Op.gte]: rating
                    }
                },
                order: [
                    orderField && order ? [orderField, order] : ['createdAt', 'DESC']
                ]
            });
        return tReviews;
    } catch (error) {
        return error.data
    }
}

const createReview = async (review) => {
    const { stars, description, user, product } = review
    const tReview = {
        stars: stars,
        description: description,
        ClientPhone: user
    }
    try {
        if(!user) return { msg: 'Provide userId.' }
        const tProduct = await Products.findByPk(product);
        const CreatedReview = await tProduct?.createReview(tReview);
        return !tProduct
            ? { msg: 'Product not found.' }
            : !CreatedReview
                ? { msg: 'Product ok. Check other fields. ' }
                : CreatedReview;
    } catch (error) {
        console.log(error);
        return error.data
    }
}

const updateReview = async (review) => {
    const { start, description, user, product } = review
    try {
        const review = await Reviews.update({
            stars: start,
            description: description
        }, {
            where: {
                ClientPhone: user,
                ProductIdProduct: product
            }
        });
        return review;
    } catch (error) {
        return error.data
    }
}

module.exports = {
    createReview,
    updateReview,
    getReviews
    // deleteReview,
};