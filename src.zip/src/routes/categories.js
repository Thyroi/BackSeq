const route = require("express").Router();
// const {getCategories, addCategory, addCollection, populateCat} = require('../controllers/Categories');

// route.get("/",getCategories);
// route.post("/",populateCat);

module.exports = route;